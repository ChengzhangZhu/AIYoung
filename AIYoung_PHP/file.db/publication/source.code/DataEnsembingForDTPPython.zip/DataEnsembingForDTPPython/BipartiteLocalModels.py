import CommonTool;
from sklearn import svm


def blm_classifier(train_sample_set, test_sample_set, drug_sim_map, target_sim_map):
    true_labels = [];
    predict_probability_list=[];
    train_drug_list, train_target_list = CommonTool.extract_drug_target(train_sample_set);
    for sample in test_sample_set:
        items = sample.split(CommonTool.split_str);
        drug = items[0];
        target = items[1];
        true_labels.append(items[2]);

        # Predict from drug side
        remain_drug_list = list_besides_entity(train_drug_list,drug);
        entity_label_map = get_entity_label_map(remain_drug_list, train_sample_set, target, "drug");
        train_kernel, train_labels = get_kernel(remain_drug_list, remain_drug_list, drug_sim_map, entity_label_map);
        test_kernel, test_label_null = get_kernel([drug], remain_drug_list, drug_sim_map, entity_label_map);
        if if_single_value(train_labels):
            predict_probability_drug = 0;
        else:
            model = svm.SVC(kernel='precomputed', probability=True);
            model.fit(train_kernel, train_labels);
            predict_label_list = model.predict(test_kernel);
            predict_score_list = model.predict_proba(test_kernel);
            predict_probability_drug = CommonTool.get_ps_predict_probability(predict_label_list, predict_score_list)

        # Predict from target side
        remain_target_list = list_besides_entity(train_target_list, target);
        entity_label_map = get_entity_label_map(remain_target_list, train_sample_set, drug, "target");
        train_kernel, train_labels = get_kernel(remain_target_list, remain_target_list, target_sim_map, entity_label_map);
        test_kernel, test_label_null = get_kernel([target], remain_target_list, target_sim_map, entity_label_map);
        if if_single_value(train_labels):
            predict_probability_target = 0;
        else:
            model = svm.SVC(kernel='precomputed', probability=True);
            model.fit(train_kernel, train_labels);
            predict_label_list = model.predict(test_kernel);
            predict_score_list = model.predict_proba(test_kernel);
            predict_probability_target = CommonTool.get_ps_predict_probability(predict_label_list, predict_score_list)

        # Merge the results
        predict_probability_list.append((predict_probability_drug[0]+predict_probability_target[0])/2);
    return predict_probability_list, true_labels;


# Get the entity list apart from a specified entity
def list_besides_entity(entity_list, query_entity):
    new_entity_list = [];
    for entity in entity_list:
        if not entity == query_entity:
            new_entity_list.append(entity);
    return new_entity_list;


# Get labels of entities
def get_entity_label_map(remain_entity_list, train_sample_set, opp_entity, type):
    entity_label_map = {};
    if type == "drug":
        for remain_entity in remain_entity_list:
            item = remain_entity + CommonTool.split_str + opp_entity + CommonTool.split_str + "1";
            if item in train_sample_set:
                entity_label_map[remain_entity] = 1;
            else:
                entity_label_map[remain_entity] = 0;
    elif type == "target":
        for remain_entity in remain_entity_list:
            item = opp_entity + CommonTool.split_str + remain_entity + CommonTool.split_str + "1";
            if item in train_sample_set:
                entity_label_map[remain_entity] = 1;
            else:
                entity_label_map[remain_entity] = 0;
    return entity_label_map;

# Get kernel
def get_kernel(entity_list, ref_entity_list, entity_sim_map, entity_label_map):
    kernel = [];
    labels = [];
    for entity1 in entity_list:
        row = [];
        for entity2 in ref_entity_list:
            drug_sim = 0;
            if entity1 == entity2:
                drug_sim = 1;
            else:
                key = entity1 + CommonTool.split_str + entity2;
                if not entity_sim_map.has_key(key):
                    key = entity2 + CommonTool.split_str + entity1;
                    if entity_sim_map.has_key(key):
                        drug_sim = entity_sim_map[key];
                    else:
                        print entity1 + "&" + entity2 + ' do not have similarity in similarity map.'
                else:
                    drug_sim = entity_sim_map[key];
            row.append(drug_sim);
        kernel.append(row);
        if entity_label_map.has_key(entity1):
            labels.append(entity_label_map[entity1]);
    return kernel, labels;


# Judge whether the labels have
# a single value or two values
def if_single_value(labels):
    classSet = set();
    for label in labels:
        classSet.add(label);
    if len(classSet) == 1:
        return True;
    return False;