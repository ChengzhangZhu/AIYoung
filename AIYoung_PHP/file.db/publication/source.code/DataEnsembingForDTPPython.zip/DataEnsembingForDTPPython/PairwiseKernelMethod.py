import CommonTool;
import NegativeSampleSelection;
import EnsemblingLearning;


# Pairwise Kernel Method classification
def pair_wise_kernel_classifier(train_sample_set, test_sample_set, drug_sim_map, target_sim_map):
    train_kernel, train_labels = cal_kernel(train_sample_set, train_sample_set, drug_sim_map, target_sim_map);
    test_kernel, test_labels = cal_kernel(train_sample_set, test_sample_set, drug_sim_map, target_sim_map);

    from sklearn import svm
    model = svm.SVC(kernel='precomputed', probability=True);
    model.fit(train_kernel, train_labels);

    predict_label_list = model.predict(test_kernel);
    predict_score_list = model.predict_proba(test_kernel);
    predict_probability = CommonTool.get_ps_predict_probability(predict_label_list, predict_score_list)
    return predict_probability, test_labels;


# Calculate the kernel
def cal_kernel(train_sample_set, sample_set,drug_sim_map, target_sim_map):
    tss_size = len(train_sample_set);
    ss_size = len(sample_set);
    kernel = [];
    labels = [];
    for index1 in range(0,ss_size):
        row = [];
        items1 = sample_set[index1].split(CommonTool.split_str);
        for index2 in range(0, tss_size):
            items2 = train_sample_set[index2].split(CommonTool.split_str);
            if len(items1) == 3 and len(items2) == 3:
                drug_sim = 0;
                if items1[0] == items2[0]:
                    drug_sim = 1;
                else:
                    key = items1[0] + CommonTool.split_str + items2[0];
                    if not drug_sim_map.has_key(key):
                        key = items2[0] + CommonTool.split_str + items1[0];
                        if drug_sim_map.has_key(key):
                            drug_sim = drug_sim_map[key];
                        else:
                            print items1[0] +"&" + items2[0] + ' do not have similarity in drug similarity map.'
                    else:
                        drug_sim = drug_sim_map[key];

                target_sim = 0;
                if items1[1] == items2[1]:
                    target_sim = 1;
                else:
                    key = items1[1] + CommonTool.split_str + items2[1];
                    if not target_sim_map.has_key(key):
                        key = items2[1] + CommonTool.split_str + items1[1];
                        if target_sim_map.has_key(key):
                            target_sim = target_sim_map[key];
                        else:
                            print items1[1] + "&" + items2[1] + ' do not have similarity in target similarity map.'
                    else:
                        target_sim = target_sim_map[key];
                row.append(drug_sim*target_sim);
            else:
                row.append(0);
                print "Format not valid:" +items1+","+items2;
        labels.append(items1[2]);
        kernel.append(row);
    return kernel,labels;


# Extract drugs and targets from set
def extract_drug_target(sample_set):
    drug_list = [];
    target_list = [];
    for line in sample_set:
        items = line.split(CommonTool.split_str);
        if len(items) == 3:
            if not items[0] in drug_list:
                drug_list.append(items[0]);
            if not items[1] in target_list:
                target_list.append(items[1]);
    return drug_list, target_list;


# Load drug/target similarity map
def load_sim_map(sim_file_path):
    sim_map = {};
    lines = CommonTool.list_file_reader(sim_file_path);
    for line in lines:
        items = line.split(CommonTool.split_str);
        if len(items) == 3:
            sim_map[items[0]+CommonTool.split_str+items[1]] = float(items[2]);
    return sim_map;


# Classify via x-fold cross validation
def cv_pkm(fold_num):
    positive_sample_list = CommonTool.list_file_reader(CommonTool.base_dir + "/Vector/FormattedPositiveSampleList.csv");
    # positive_sample_list = positive_sample_list[0:100];
    negative_sample_size = len(positive_sample_list);
    negative_sample_list = NegativeSampleSelection.random_negative_samples(positive_sample_list, negative_sample_size);
    splited_folds_ps = EnsemblingLearning.split_sample_folds(positive_sample_list,fold_num);
    splited_folds_ns = EnsemblingLearning.split_sample_folds(negative_sample_list, fold_num);

    drug_sim_map = load_sim_map(CommonTool.base_dir + "\Similarity\DrugCSSim.csv");
    target_sim_map = load_sim_map(CommonTool.base_dir + "\Similarity\TargetSeqSim.csv");
    predict_probabilities = [];
    for foldIndex1 in range(0,fold_num):
        # Initiate the test sample set
        test_sample_set = [];
        test_sample_set.extend(splited_folds_ps[foldIndex1]);
        test_sample_set.extend(splited_folds_ns[foldIndex1]);
        # Initiate the training sample set
        train_sample_set = [];
        for foldIndex2 in range(0, fold_num):
            if not foldIndex1 == foldIndex2:
                train_sample_set.extend(splited_folds_ps[foldIndex2]);
                train_sample_set.extend(splited_folds_ns[foldIndex2]);

        # Classification
        predict_probabilities.extend(pair_wise_kernel_classifier(train_sample_set, test_sample_set, drug_sim_map, target_sim_map));


# Main function
if __name__ == '__main__':
    cv_pkm(5);