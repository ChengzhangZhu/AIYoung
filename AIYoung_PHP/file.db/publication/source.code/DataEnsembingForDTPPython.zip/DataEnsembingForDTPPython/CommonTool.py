import os
import re

base_dir = "F:\UTSLearning\MyPapers\DataEnsemblingForSEPs\Experiments";
# base_dir = "/home/yzheng1/Justice/DataEnsemblingForSEPs/Python";
# base_dir = "/home/yzheng1/Data/Justice/DataEnsemblingForSEPs/Python";

split_str="@-@";


# Read lines as a list from the specified file
def list_file_reader(file_path):
    file = open(file_path, 'r');
    list = [];
    line = file.readline();
    while line:
        list.append(line.strip('\n'));
        line = file.readline();
    file.close();
    return list;


# Write a list to a desired file
def list_file_writer(list,save_file_path):
    create_parent_dir_not_exist(save_file_path);
    desired_file = open(save_file_path, 'w');
    for line in list:
        desired_file.write(line+'\n');
    desired_file.close();


# Get paths of all files in the specified directory
def get_files_in_dir(dir):
    list_dirs = os.walk(dir)
    file_path_list=[];
    for root, dirs, files in list_dirs:
        for f in files:
            file_path_list.append(os.path.join(root, f));
    return file_path_list;


# Create file if not exist
def create_parent_dir_not_exist(file_path):
    parent_dir=os.path.dirname(file_path);
    if not os.path.exists(parent_dir):
        os.makedirs(parent_dir);


# Get a random number list
def get_random_num_list(upper_limit,size):
    import random;
    random_num_list=[];
    for i in range(0,upper_limit):
        random_num_list.append(i);
    random.shuffle(random_num_list);
    return random_num_list;


# Get a random number list
def get_random_num(upper_limit):
    import random;
    return int(random.uniform(0,(upper_limit-1)));


# Get a random number list
def myLog(log_str):
    import time;
    print time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())+"  "+log_str;


# Get positive sample predict probability
def get_ps_predict_probability(predict_label_list,predict_score_list):
    list_len = len(predict_label_list);
    probability_list = [];
    if list_len == len(predict_score_list):
        for index in range(0,list_len):
            p1 = predict_score_list[index][0];
            p2 = predict_score_list[index][1];
            if int(predict_label_list[index]) == 1:
                if p1 > p2:
                    probability = p1;
                else:
                    probability = p2;
            else:
                if p1 > p2:
                    probability = p2;
                else:
                    probability = p1;
            probability_list.append(probability);
    else:
        print "predict_label_list and predict_score_list size not equal."
    return probability_list;


# Split the positive/negative samples into x-fold
def split_sample_folds(sample_list,fold_num):
    sample_list_size = len(sample_list);
    random_index_list = get_random_num_list(sample_list_size,sample_list_size);
    sample_num_per_fold = int(sample_list_size/fold_num);
    sample_folds = [];
    for i in range(0,fold_num):
        start = i*sample_num_per_fold;
        end = start+sample_num_per_fold;
        sample_fold = [];
        for j in range(int(start),int(end)):
            sample_fold.append(sample_list[random_index_list[j]]);
        sample_folds.append(sample_fold);
    for j in range(fold_num*sample_num_per_fold,sample_list_size):
        sample_folds[0].append(sample_list[random_index_list[j]]);
    return sample_folds;


# Get positive sample predict probability
def get_ps_predict_probability(predict_label_list,predict_score_list):
    list_len = len(predict_label_list);
    probability_list = [];
    if list_len == len(predict_score_list):
        for index in range(0,list_len):
            p1 = predict_score_list[index][0];
            p2 = predict_score_list[index][1];
            if int(predict_label_list[index]) == 1:
                if p1 > p2:
                    probability = p1;
                else:
                    probability = p2;
            else:
                if p1 > p2:
                    probability = p2;
                else:
                    probability = p1;
            #print str(predict_label_list[index])+','+str(probability);
            probability_list.append(probability);
    else:
        print "predict_label_list and predict_score_list size not equal."
    return probability_list;


# Calculate the AUC
def cal_auc(predict_probabilities, true_labels):
    from sklearn.metrics import roc_auc_score
    import numpy
    true_labels = numpy.asarray(true_labels, 'i');
    predict_probabilities = numpy.asarray(predict_probabilities);
    return roc_auc_score(true_labels, predict_probabilities);


# Get drug/target vector map
def get_vector_map(vector_path):
    vector_list = list_file_reader(vector_path);
    vector_map = {};
    for vector in vector_list:
        items = vector.split(',');
        nums = [];
        for index in range(1,len(items)):
            if len(items[index]) > 0:
                nums.append(float(items[index]));
        vector_map[items[0]] = nums;
    return vector_map;


# Merge drug vector and target vector
def merge_drug_target_vector(drug_vector_map,target_vector_map,sample_set):
    merged_vectors = [];
    merged_labels = [];
    for sample in sample_set:
        merged_vector = [];
        entities = sample.split(split_str);
        drug_vector = drug_vector_map[entities[0]];
        target_vector = target_vector_map[entities[1]];
        merged_vector.extend(drug_vector);
        merged_vector.extend(target_vector);
        merged_vectors.append(merged_vector);
        merged_labels.append(entities[2]);
    return merged_vectors, merged_labels;


# Extract drugs and targets from set
def extract_drug_target(sample_set):
    drug_list = [];
    target_list = [];
    for line in sample_set:
        items = line.split(split_str);
        if len(items) == 3:
            if not items[0] in drug_list:
                drug_list.append(items[0]);
            if not items[1] in target_list:
                target_list.append(items[1]);
    return drug_list, target_list;


# Main function
if __name__ == '__main__':
    # file_path=base_dir+"\Vector\DrugList.csv";
    # list=list_file_reader(file_path);
    # list_file_writer(list,file_path+".new");
    # get_files_in_dir(base_dir);
    random_num_list = get_random_num_list(7, 7);
    for num in random_num_list:
        print num;