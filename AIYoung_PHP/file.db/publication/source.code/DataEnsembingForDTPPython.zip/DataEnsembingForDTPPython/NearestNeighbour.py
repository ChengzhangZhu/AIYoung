import CommonTool;
import NegativeSampleSelection;
import EnsemblingLearning;


# Nearest neighbour classification
def nearest_neighbour_classifier(positive_sample_list, train_sample_set, test_sample_set, drug_sim_map,target_sim_map):
    train_drug_list, train_target_list = CommonTool.extract_drug_target(train_sample_set);
    predict_probability_list = [];
    true_labels = [];
    for sample in test_sample_set:
        items = sample.split(CommonTool.split_str);
        predict_probability = [];
        if len(items) == 3:
            max_drug_sim, nearest_drug = nearest_entity(train_drug_list, drug_sim_map, items[0]);
            max_target_sim, nearest_target = nearest_entity(train_target_list, target_sim_map, items[1]);
            if (nearest_drug + CommonTool.split_str + items[1] + CommonTool.split_str + "1") in positive_sample_list:
                predict_probability.append(max_drug_sim);
            else:
                predict_probability.append(0);
            if (items[0] + CommonTool.split_str + nearest_target + CommonTool.split_str + "1") in positive_sample_list:
                predict_probability.append(max_target_sim);
            else:
                predict_probability.append(0);
            true_labels.append(items[2]);
        else:
            predict_probability.append(0);
            predict_probability.append(0);
            true_labels.append(0);
        predict_probability_list.append((predict_probability[0]+predict_probability[1])/2);
    return predict_probability_list, true_labels;


# Get the most similar entity (i.e., drug/target)
def nearest_entity(train_entity_list, entity_sim_map, entity):
    max_sim = -1;
    max_sim_entity = "";
    for train_entity in train_entity_list:
        if not train_entity == entity:
            cur_sim = 0;
            key = train_entity + CommonTool.split_str + entity;
            if not entity_sim_map.has_key(key):
                key = entity + CommonTool.split_str + train_entity;
                if entity_sim_map.has_key(key):
                    cur_sim = entity_sim_map[key];
                else:
                    print entity + CommonTool.split_str + train_entity + ' do not exist.'
            else:
                cur_sim = entity_sim_map[key];
            if max_sim < cur_sim:
                max_sim = cur_sim;
                max_sim_entity = train_entity;
    return float(max_sim), max_sim_entity;


# Load drug/target similarity map
def load_sim_map(sim_file_path):
    sim_map = {};
    lines = CommonTool.list_file_reader(sim_file_path);
    for line in lines:
        items = line.split(CommonTool.split_str);
        if len(items) == 3:
            sim_map[items[0]+CommonTool.split_str+items[1]] = float(items[2]);
    return sim_map;


# Classify via x-fold cross validation
def cv_nn(fold_num):
    positive_sample_list = CommonTool.list_file_reader(CommonTool.base_dir + "/Vector/FormattedPositiveSampleList.csv");
    negative_sample_size = len(positive_sample_list);
    negative_sample_list = NegativeSampleSelection.random_negative_samples(positive_sample_list, negative_sample_size);
    splited_folds_ps = EnsemblingLearning.split_sample_folds(positive_sample_list,fold_num);
    splited_folds_ns = EnsemblingLearning.split_sample_folds(negative_sample_list, fold_num);

    drug_sim_map = load_sim_map(CommonTool.base_dir + "\Similarity\DrugCSSim.csv");
    target_sim_map = load_sim_map(CommonTool.base_dir + "\Similarity\TargetSeqSim.csv");
    predict_probabilities = [];
    for foldIndex1 in range(0,fold_num):
        # Initiate the test sample set
        test_sample_set = [];
        test_sample_set.extend(splited_folds_ps[foldIndex1]);
        test_sample_set.extend(splited_folds_ns[foldIndex1]);
        # Initiate the training sample set
        train_sample_set = [];
        for foldIndex2 in range(0, fold_num):
            if not foldIndex1 == foldIndex2:
                train_sample_set.extend(splited_folds_ps[foldIndex2]);
                train_sample_set.extend(splited_folds_ns[foldIndex2]);

        # Classification
        predict_probabilities.extend(nearest_neighbour_classifier(positive_sample_list, train_sample_set, test_sample_set, drug_sim_map, target_sim_map));


# Main function
if __name__ == '__main__':
    cv_nn(5);