import CommonTool;


# Format the drug vectors and target vectors from matlab
def format_vector(name_list,vector_list):
    name_list_len = len(name_list);
    formatted_vectors = [];
    if name_list_len==len(vector_list):
        for index in range(0,name_list_len):
            formatted_vectors.append(name_list[index]+","+vector_list[index]);
    else:
        print "The size of name_list and vector_list don't equal";
    return formatted_vectors;


# Format vectors in the directory
def format_vectors_in_dir(vector_dir,name_file_path):
    from os.path import dirname, basename
    save_dir = dirname(vector_dir)+'\\Formatted'+basename(vector_dir)+'\\';
    CommonTool.create_parent_dir_not_exist(save_dir);
    file_path_list = CommonTool.get_files_in_dir(vector_dir);
    name_list = CommonTool.list_file_reader(name_file_path);
    for file_path in file_path_list:
        formatted_vectors = format_vector(name_list, CommonTool.list_file_reader(file_path));
        CommonTool.list_file_writer(formatted_vectors,save_dir+'Formatted'+basename(file_path));


# Format positive samples
def format_positive_samples(positive_sample_list,save_path):
    formatted_positive_sample_list = [];
    for positive_sample in positive_sample_list:
        formatted_positive_sample_list.append(positive_sample+CommonTool.split_str+"1");
    CommonTool.list_file_writer(formatted_positive_sample_list,save_path);


# Main function
if __name__ == '__main__':
    # Format vector files in directory
    # base_dir = CommonTool.base_dir+"\Vector\CompressedVectors\\";
    # for compress_type in ["AnchorHash","PCA"]:
    #     for vector_type in ["DrugVector","TargetVector"]:
    #         vector_dir = base_dir+compress_type+"\\"+vector_type;
    #         if vector_type == "DrugVector":
    #             name_file_path = CommonTool.base_dir+"\Vector\DrugList.csv";
    #         else:
    #             name_file_path  =  CommonTool.base_dir + "\Vector\TargetList.csv";
    #         format_vectors_in_dir(vector_dir, name_file_path);

    # Format vector files in directory
    base_dir = CommonTool.base_dir + "\Vector\CompressedVectors\\";
    for compress_type in ["AnchorHash_100anchors"]:
        for vector_type in ["DrugVector", "TargetVector"]:
            vector_dir = base_dir + compress_type + "\\" + vector_type;
            if vector_type == "DrugVector":
                name_file_path = CommonTool.base_dir + "\Vector\DrugList.csv";
            else:
                name_file_path = CommonTool.base_dir + "\Vector\TargetList.csv";
            format_vectors_in_dir(vector_dir, name_file_path);

    # Format positive samples
    # positive_sample_list = CommonTool.list_file_reader(CommonTool.base_dir + "\Vector\InteractionList");
    # save_path = CommonTool.base_dir + "\Vector\FormattedPositiveSampleList.csv";
    # format_positive_samples(positive_sample_list, save_path);