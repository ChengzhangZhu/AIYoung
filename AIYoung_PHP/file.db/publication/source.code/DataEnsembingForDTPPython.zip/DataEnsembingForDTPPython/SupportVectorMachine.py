import CommonTool;
import MLHelper;

# SVM
def svm_classifier(train_sample_set, test_sample_set, drug_vector_map_path, target_vector_map_path):
    drug_vector_map = CommonTool.get_vector_map(drug_vector_map_path);
    target_vector_map = CommonTool.get_vector_map(target_vector_map_path);
    # Get the merged test and train vectors
    test_vectors, test_labels = CommonTool.merge_drug_target_vector(drug_vector_map, target_vector_map, test_sample_set);
    train_vectors, train_labels = CommonTool.merge_drug_target_vector(drug_vector_map, target_vector_map, train_sample_set);

    # Prediction
    model = MLHelper.svm_classifier(train_vectors, train_labels);
    predict_label_list = model.predict(test_vectors);
    predict_score_list = model.predict_proba(test_vectors);
    predict_probability = CommonTool.get_ps_predict_probability(predict_label_list,predict_score_list)

    return predict_probability, test_labels;