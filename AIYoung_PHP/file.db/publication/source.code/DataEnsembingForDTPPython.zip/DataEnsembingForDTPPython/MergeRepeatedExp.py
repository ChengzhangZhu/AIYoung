import CommonTool


# Merge repeated results stored in CSV file (repeated times=25)
def merge_repeated_results(dir, save_path):
    merge_lines=[];
    file_path_list = CommonTool.get_files_in_dir(dir)
    for file_path in file_path_list:
        lines = CommonTool.list_file_reader(file_path)
        merge_lines.extend(lines);
    CommonTool.list_file_writer(merge_lines,save_path)


# Main function
if __name__ == '__main__':
    base_dir= "F:\UTSLearning\MyPapers\DataEnsemblingForSEPs\Experiments\Result\python\Comparison_NSRatio=1_Formatted\\"
    # dir_names = ["AnchorHash","NN","PKM"]
    dir_names = ["BLM"]
    for dir_name in dir_names:
        dir = base_dir + dir_name;
        save_path = base_dir + dir_name + "_25Merge.csv"
        merge_repeated_results(dir, save_path)