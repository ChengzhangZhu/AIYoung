import xgboost as xgb
import numpy
import sklearn

import numpy as np
# data = np.random.rand(5,10) # 5 entities, each contains 10 features
# label = np.random.randint(2, size=5) # binary target
# dtrain = xgb.DMatrix( data, label=label)
# dtest = dtrain
# param = {'bst:max_depth':2, 'bst:eta':1, 'silent':1, 'objective':'binary:logistic' }
# param['nthread'] = 4
# param['eval_metric'] = 'auc'
# evallist = [(dtest,'eval'), (dtrain,'train')]
# num_round = 10
# bst = xgb.train( param, dtrain, num_round, evallist )
# bst.dump_model('dump.raw.txt')
# xgb.DMatrix();

# mu,sigma=0,0.1;
# train_vectors = np.random.rand(50,10);
# train_labels = numpy.random.randint(2,size=50);
#
# test_vectors = np.random.rand(10,10);
# test_labels = numpy.random.randint(2,size=10);
#
# train_matrix = xgb.DMatrix(train_vectors, label=train_labels);
# test_matrix = xgb.DMatrix(test_vectors, label=test_labels);
#
# param = {
#         'bst:max_depth':2,
#         'bst:eta':1,
#         'silent':1,
#         'objective':'binary:logistic',
#         'nthread':4,
#         'eval_metric':'auc'
#     };
# model = xgb.train(param, train_matrix, 10);
# # predict_scores = model.predict(test_matrix);
# predict_scores = model.predict(test_matrix);
# print sklearn.metrics.roc_auc_score(test_labels, predict_scores);

# X = np.array([[0, 0], [1, 1]])
# gram = np.dot(X, X.T)
# print gram;
#print predict_scores

# target_vector_map_path = ("/FormattedTargetVector/FormattedAnchorHashTargetVector"
#                           "/FormattedTargetVector/FormattedAnchorHashTargetVector");
# print target_vector_map_path;

# from time import ctime, sleep, time
# import timeit
# start = timeit.default_timer()
# sleep(2)
# elapsed = round(timeit.default_timer() - start,2)
# print elapsed

# import timeit
#
# start = timeit.default_timer()
# elapsed = (timeit.default_timer() - start)
#
# print str(elapsed);

# Extract the top 20000 rows of a large file
import CommonTool

input_file_path = "F:\Projects\Cooperation\MLA\SourceOrDestinationPIC=XXXXXXXX.csv"
output_file_path = "F:\Projects\Cooperation\MLA\SourceOrDestinationPIC=XXXXXXXX&20000.csv"
lines = CommonTool.list_file_reader(input_file_path);

file = open(input_file_path, 'r');
list = [];
line = file.readline();
line_num_th = 20000;
while line and line_num_th>0:
    list.append(line.strip('\n'));
    line = file.readline();
    line_num_th = line_num_th - 1;
file.close();

desired_file = open(output_file_path, 'w');
for line in list:
    desired_file.write(line+'\n');
desired_file.close();
