import CommonTool;
import MLHelper;
import NegativeSampleSelection;


# Classify via x-fold cross validation
def cross_validation(drug_vector_map_path,target_vector_map_path,positive_sample_list,negative_sample_list,classifier,save_path,fold_num):
    splited_folds_ps = split_sample_folds(positive_sample_list,fold_num);
    splited_folds_ns = split_sample_folds(negative_sample_list, fold_num);
    drug_vector_map = get_vector_map(drug_vector_map_path);
    target_vector_map = get_vector_map(target_vector_map_path);

    true_labels = [];
    predict_results = [];
    predict_probabilities = [];
    for foldIndex1 in range(0,fold_num):
        # Initiate the test sample set
        test_sample_set=[];
        test_sample_set.extend(splited_folds_ps[foldIndex1]);
        test_sample_set.extend(splited_folds_ns[foldIndex1]);
        # Initiate the training sample set
        train_sample_set=[];
        for foldIndex2 in range(0, fold_num):
            if not foldIndex1==foldIndex2:
                train_sample_set.extend(splited_folds_ps[foldIndex2]);
                train_sample_set.extend(splited_folds_ns[foldIndex2]);
        # Get the merged test and train vectors
        test_vectors,test_labels=merge_drug_target_vector(drug_vector_map,target_vector_map,test_sample_set);
        train_vectors,train_labels = merge_drug_target_vector(drug_vector_map, target_vector_map, train_sample_set);

        # Classification
        true_labels.extend(test_labels);
        model=classifier(train_vectors,train_labels);
        fold_predict_label_list = model.predict(test_vectors);
        fold_predict_score_list = model.predict_proba(test_vectors);
        fold_predict_probability = get_ps_predict_probability(fold_predict_label_list, fold_predict_score_list)
        for index in range(0,len(fold_predict_probability)):
            predict_probabilities.append(fold_predict_probability[index]);
            predict_results.append(test_sample_set[index].replace(CommonTool.split_str,",").replace("\n","")+','+str(fold_predict_probability[index]));
    CommonTool.list_file_writer(predict_results,save_path);

    # Calculate AUC score
    import os.path
    import numpy as np;
    from sklearn.metrics import roc_auc_score;
    true_labels = np.asarray(true_labels, 'i');
    predict_probabilities = np.asarray(predict_probabilities);
    auc_str = os.path.basename(save_path) + ',' + str(roc_auc_score(true_labels, predict_probabilities));
    print auc_str;
    return auc_str;


# Classify via x-fold cross validation
def cross_validation_xgboost(drug_vector_map_path,target_vector_map_path,positive_sample_list,negative_sample_list,classifier,rounds,save_path,fold_num):
    import xgboost;
    import numpy as np;
    splited_folds_ps = split_sample_folds(positive_sample_list,fold_num);
    splited_folds_ns = split_sample_folds(negative_sample_list, fold_num);
    drug_vector_map = get_vector_map(drug_vector_map_path);
    target_vector_map = get_vector_map(target_vector_map_path);

    true_labels = [];
    predict_results = [];
    predict_probabilities = [];
    for foldIndex1 in range(0,fold_num):
        # Initiate the test sample set
        test_sample_set=[];
        test_sample_set.extend(splited_folds_ps[foldIndex1]);
        test_sample_set.extend(splited_folds_ns[foldIndex1]);
        # Initiate the training sample set
        train_sample_set=[];
        for foldIndex2 in range(0, fold_num):
            if not foldIndex1==foldIndex2:
                train_sample_set.extend(splited_folds_ps[foldIndex2]);
                train_sample_set.extend(splited_folds_ns[foldIndex2]);
        # Get the merged test and train vectors
        test_vectors,test_labels=merge_drug_target_vector(drug_vector_map,target_vector_map,test_sample_set);
        train_vectors,train_labels = merge_drug_target_vector(drug_vector_map, target_vector_map, train_sample_set);
        # Classification
        true_labels.extend(test_labels);
        model=classifier(train_vectors,train_labels,rounds);
        test_vectors = np.asarray(test_vectors);
        test_labels = np.asarray(test_labels);
        test_matrix = xgboost.DMatrix(test_vectors, label=test_labels);
        fold_predict_probability = model.predict(test_matrix);
        # Save results of current fold
        test_size = len(test_sample_set);
        for index in range(0,test_size):
            predict_probabilities.append(fold_predict_probability[index]);
            predict_results.append(test_sample_set[index].replace(CommonTool.split_str,",").replace("\n","")+","+str(fold_predict_probability[index]));
    CommonTool.list_file_writer(predict_results,save_path);

    # Calculate AUC score
    import os.path
    from sklearn.metrics import roc_auc_score
    true_labels = np.asarray(true_labels, 'i');
    predict_probabilities = np.asarray(predict_probabilities);
    auc_str = os.path.basename(save_path) + ',' + str(roc_auc_score(true_labels, predict_probabilities));
    print auc_str;
    return auc_str;


# Get drug/target vector map
def get_vector_map(vector_path):
    vector_list = CommonTool.list_file_reader(vector_path);
    vector_map = {};
    for vector in vector_list:
        items = vector.split(',');
        nums = [];
        for index in range(1,len(items)):
            nums.append(float(items[index]));
        vector_map[items[0]] = nums;
    return vector_map;


# Merge drug vector and target vector
def merge_drug_target_vector(drug_vector_map,target_vector_map,sample_set):
    merged_vectors = [];
    merged_labels = [];
    for sample in sample_set:
        merged_vector = [];
        entities = sample.split(CommonTool.split_str);
        drug_vector = drug_vector_map[entities[0]];
        target_vector = target_vector_map[entities[1]];
        merged_vector.extend(drug_vector);
        merged_vector.extend(target_vector);
        merged_vectors.append(merged_vector);
        merged_labels.append(entities[2]);
    return merged_vectors, merged_labels;


# Split the positive/negative samples into x-fold
def split_sample_folds(sample_list,fold_num):
    sample_list_size = len(sample_list);
    random_index_list = CommonTool.get_random_num_list(sample_list_size,sample_list_size);
    sample_num_per_fold = int(sample_list_size/fold_num);
    sample_folds = [];
    for i in range(0,fold_num):
        start = i*sample_num_per_fold;
        end = start+sample_num_per_fold;
        sample_fold = [];
        for j in range(int(start),int(end)):
            sample_fold.append(sample_list[random_index_list[j]]);
        sample_folds.append(sample_fold);
    for j in range(fold_num*sample_num_per_fold,sample_list_size):
        sample_folds[0].append(sample_list[random_index_list[j]]);
    return sample_folds;


# Get positive sample predict probability
def get_ps_predict_probability(predict_label_list,predict_score_list):
    list_len = len(predict_label_list);
    probability_list = [];
    if list_len == len(predict_score_list):
        for index in range(0,list_len):
            p1 = predict_score_list[index][0];
            p2 = predict_score_list[index][1];
            if int(predict_label_list[index]) == 1:
                if p1 > p2:
                    probability = p1;
                else:
                    probability = p2;
            else:
                if p1 > p2:
                    probability = p2;
                else:
                    probability = p1;
            #print str(predict_label_list[index])+','+str(probability);
            probability_list.append(probability);
    else:
        print "predict_label_list and predict_score_list size not equal."
    return probability_list;


# Main function
if __name__ == '__main__':
    # Common settings
    auc_list=[];
    fold_num = 10;
    cv_repeat_times = 1;
    # ns_ratios = [0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 5, 6, 7, 8, 9, 10];
    # ns_ratios = [0.5, 1, 1.5, 2, 3, 3.5];
    ns_ratios = [1];
    classifiers = {
                   # 'NB': MLHelper.naive_bayes_classifier,
                   'KNN': MLHelper.knn_classifier,
                   # 'LR': MLHelper.logistic_regression_classifier,
                   'RF': MLHelper.random_forest_classifier,
                   # 'DT': MLHelper.decision_tree_classifier,
                   'SVM': MLHelper.svm_classifier,
                   'SVMCV': MLHelper.svm_cross_validation,
                   # 'GBDT': MLHelper.gradient_boosting_classifier,
                   # 'XGB': MLHelper.xgboost
                   }
    positive_sample_list = CommonTool.list_file_reader(CommonTool.base_dir + "/Vector/FormattedPositiveSampleList.csv");

    for ns_ratio in ns_ratios:
        for cv_index in range(1,(cv_repeat_times+1)):
            negative_sample_size = (int)(ns_ratio*len(positive_sample_list));
            negative_sample_list = NegativeSampleSelection.random_negative_samples(positive_sample_list,negative_sample_size);

            # For XGB classifier
            # Classification for anchor hash compressed vectors
            # layers = [1, 2];
            # bits = [12, 16, 24, 32, 48, 64];
            # layers = [1];
            # bits = [48];
            # base_dir = CommonTool.base_dir + "/Vector/CompressedVectors/AnchorHash";
            # for bit in bits:
            #     for layer in layers:
            #         if not (layer == 1 and bit == 64):
            #             drug_vector_map_path = base_dir + "/FormattedDrugVector/FormattedAnchorHashDrugVector" + str(
            #                 bit) + "_" + str(layer) + ".csv";
            #             target_vector_map_path = base_dir + "/FormattedTargetVector/FormattedAnchorHashTargetVector" + str(
            #                 bit) + "_" + str(layer) + ".csv";
            #             save_path = CommonTool.base_dir + "/Result/python/AnchorHash(ns_ratio="+str(ns_ratio)+",cv_index="+\
            #                 str(cv_index)+",bit=" + str(bit) + ",layer=" + str(layer) + ",classifier=XGB).csv";
            #             auc_str = cross_validation_xgboost(drug_vector_map_path, target_vector_map_path, positive_sample_list, negative_sample_list,
            #                          classifiers["XGB"], 10, save_path, fold_num);
            #             auc_list.append(auc_str);

            # Classification for PCA compressed vectors
            # bits = [12, 16, 24, 32, 48, 64, 100, 200, 500, 1000];
            # base_dir = CommonTool.base_dir + "/Vector/CompressedVectors/PCA";
            # for bit in bits:
            #     drug_vector_map_path = base_dir + "/FormattedDrugVector/FormattedPCADrugVector" + str(bit) + ".csv";
            #     target_vector_map_path = base_dir + "/FormattedTargetVector/FormattedPCATargetVector" + str(bit) + ".csv";
            #     save_path = CommonTool.base_dir + "/Result/python/PCA(ns_ratio="+str(ns_ratio)+",cv_index="+\
            #             str(cv_index)+",bit=" + str(bit)+ ",classifier=XGB).csv";
            #     auc_str = cross_validation_xgboost(drug_vector_map_path, target_vector_map_path, positive_sample_list, negative_sample_list, classifiers["XGB"], 10, save_path, fold_num);
            #     auc_list.append(auc_str);

            # For other classifiers
            for classifier in classifiers:
                # Classification for anchor hash compressed vectors
                # layers = [1,2];
                # bits = [12, 16, 24, 32, 48, 64];
                layers = [1];
                bits = [48];
                print 'classifier='+ classifier
                base_dir = CommonTool.base_dir + "/Vector/CompressedVectors/AnchorHash";
                for bit in bits:
                    for layer in layers:
                        if not (layer==1 and bit==64):
                            drug_vector_map_path = base_dir + "/FormattedDrugVector/FormattedAnchorHashDrugVector"+str(bit)+"_"+str(layer)+".csv";
                            target_vector_map_path = base_dir + "/FormattedTargetVector/FormattedAnchorHashTargetVector"+str(bit)+"_"+str(layer)+".csv";
                            save_path=CommonTool.base_dir+"/Result/python/AnchorHash(ns_ratio="+str(ns_ratio)+",cv_index="+\
                            str(cv_index)+",bit=" + str(bit) + ",layer=" + str(layer) + ",classifer="+classifier+").csv";
                            auc_str = cross_validation(drug_vector_map_path, target_vector_map_path, positive_sample_list, negative_sample_list,classifiers[classifier], save_path, fold_num);
                            auc_list.append(auc_str);
            #     # Classification for PCA compressed vectors
            #     bits = [12, 16, 24, 32, 48, 64, 100, 200, 500, 1000];
            #     base_dir = CommonTool.base_dir + "/Vector/CompressedVectors/PCA";
            #     for bit in bits:
            #         drug_vector_map_path = base_dir + "/FormattedDrugVector/FormattedPCADrugVector" + str(bit) + ".csv";
            #         target_vector_map_path = base_dir + "/FormattedTargetVector/FormattedPCATargetVector" + str(bit) + ".csv";
            #         save_path = CommonTool.base_dir + "/Result/python/PCA(ns_ratio="+str(ns_ratio)+",cv_index="+\
            #             str(cv_index)+",bit=" + str(bit) +",classifer="+classifier+").csv";
            #         auc_str = cross_validation(drug_vector_map_path, target_vector_map_path, positive_sample_list, negative_sample_list, classifiers[classifier], save_path, fold_num);
            #         auc_list.append(auc_str);
    CommonTool.list_file_writer(auc_list,CommonTool.base_dir+ "/Result/python/AUC_List.csv");