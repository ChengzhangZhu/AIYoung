import timeit;
import CommonTool;
import MLHelper;
import NegativeSampleSelection;
import ComparisonExp

# Ensemble learning classifier
def rf_xgb_ensemble_classifier(train_sample_set, test_sample_set, drug_vector_map_path, target_vector_map_path, classifiers, rounds):
    drug_vector_map = CommonTool.get_vector_map(drug_vector_map_path);
    target_vector_map = CommonTool.get_vector_map(target_vector_map_path);
    # Get the merged test and train vectors
    test_vectors, test_labels = CommonTool.merge_drug_target_vector(drug_vector_map, target_vector_map, test_sample_set);
    train_vectors, train_labels = CommonTool.merge_drug_target_vector(drug_vector_map, target_vector_map, train_sample_set);
    # Random Forrest
    model = classifiers["RF"](train_vectors, train_labels);
    predict_label_list = model.predict(test_vectors);
    predict_score_list = model.predict_proba(test_vectors);
    predict_probability_rf = CommonTool.get_ps_predict_probability(predict_label_list, predict_score_list)
    # XGB
    import numpy as np;
    import xgboost;
    model = classifiers["XGB"](train_vectors, train_labels, rounds);
    test_vectors = np.asarray(test_vectors);
    test_labels = np.asarray(test_labels);
    test_matrix = xgboost.DMatrix(test_vectors, label=test_labels);
    predict_probability_xgb = model.predict(test_matrix);
    # Ensemble the results
    predict_probabilities = [];
    test_size = len(test_sample_set);
    for index in range(0, test_size):
        average_predict_probability = (predict_probability_rf[index] + predict_probability_xgb[index]) / 2;
        predict_probabilities.append(average_predict_probability);
    return predict_probabilities, test_labels;


# Classify via x-fold cross validation
def cv_ensemble_learning(drug_vector_map_path,target_vector_map_path,positive_sample_list,negative_sample_list,classifiers,rounds,save_path,fold_num):
    import os.path;
    import xgboost;
    import numpy as np;

    splited_folds_ps = CommonTool.split_sample_folds(positive_sample_list,fold_num);
    splited_folds_ns = CommonTool.split_sample_folds(negative_sample_list, fold_num);
    drug_vector_map = CommonTool.get_vector_map(drug_vector_map_path);
    target_vector_map = CommonTool.get_vector_map(target_vector_map_path);

    true_labels = [];
    predict_results = [];
    predict_probabilities = [];
    for foldIndex1 in range(0,fold_num):
        # Initiate the test sample set
        test_sample_set = [];
        test_sample_set.extend(splited_folds_ps[foldIndex1]);
        test_sample_set.extend(splited_folds_ns[foldIndex1]);
        # Initiate the training sample set
        train_sample_set = [];
        for foldIndex2 in range(0, fold_num):
            if not foldIndex1 == foldIndex2:
                train_sample_set.extend(splited_folds_ps[foldIndex2]);
                train_sample_set.extend(splited_folds_ns[foldIndex2]);
        # Get the merged test and train vectors
        test_vectors,test_labels = CommonTool.merge_drug_target_vector(drug_vector_map,target_vector_map,test_sample_set);
        train_vectors,train_labels = CommonTool.merge_drug_target_vector(drug_vector_map, target_vector_map, train_sample_set);
        # Classification
        true_labels.extend(test_labels);
        # Random Forrest
        model = classifiers["RF"](train_vectors, train_labels);
        fold_predict_label_list = model.predict(test_vectors);
        fold_predict_score_list = model.predict_proba(test_vectors);
        fold_predict_probability_rf = CommonTool.get_ps_predict_probability(fold_predict_label_list, fold_predict_score_list)
        # XGB
        model = classifiers["XGB"](train_vectors,train_labels,rounds);
        test_vectors = np.asarray(test_vectors);
        test_labels = np.asarray(test_labels);
        test_matrix = xgboost.DMatrix(test_vectors, label=test_labels);
        fold_predict_probability_xgb = model.predict(test_matrix);

        test_size = len(test_sample_set);
        for index in range(0, test_size):
            prefix_str = test_sample_set[index].replace(CommonTool.split_str, ",").replace("\n", "");
            average_predict_probability = (fold_predict_probability_rf[index] + fold_predict_probability_xgb[index])/2;
            predict_probabilities.append(average_predict_probability);
            predict_results.append(prefix_str+ "," + str(average_predict_probability));
    CommonTool.list_file_writer(predict_results,save_path);

    # Calculate AUC score

    from sklearn.metrics import roc_auc_score
    true_labels = np.asarray(true_labels, 'i');
    predict_probabilities = np.asarray(predict_probabilities);
    auc_str = os.path.basename(save_path) + ',' + str(roc_auc_score(true_labels, predict_probabilities));
    print auc_str;
    return auc_str;


# Main function
if __name__ == '__main__':
    # Common settings
    ns_ratios = [1];
    fold_num = 10;
    ns_repeat_times = 5;
    cv_repeat_times = 5;
    anchor_hash_layers = [1, 2];
    anchor_hash_bits = [12, 16, 24, 32, 48, 64];
    PCA_bits = [48];
    classifiers = {
        'RF': MLHelper.random_forest_classifier,
        'XGB': MLHelper.xgboost
    };
    positive_sample_list = CommonTool.list_file_reader(CommonTool.base_dir + "/Vector/FormattedPositiveSampleList.csv");
    for ns_index in range(1, (ns_repeat_times + 1)):
        for ns_ratio in ns_ratios:
            # Initiate negative samples
            negative_sample_size = (int)(ns_ratio * len(positive_sample_list));
            negative_sample_list = NegativeSampleSelection.random_negative_samples(positive_sample_list,
                                                                                   negative_sample_size);
            for cv_index in range(1, (cv_repeat_times + 1)):
                # Split samples
                splited_folds_ps = CommonTool.split_sample_folds(positive_sample_list, fold_num);
                splited_folds_ns = CommonTool.split_sample_folds(negative_sample_list, fold_num);

                # Classification for anchor hash compressed vectors using ensemble learning
                base_dir = CommonTool.base_dir + "/Vector/CompressedVectors/AnchorHash";
                for anchor_hash_layer in anchor_hash_layers:
                    for anchor_hash_bit in anchor_hash_bits:
                        if not (anchor_hash_layer == 1 and anchor_hash_bit == 64):
                            start = timeit.default_timer();
                            drug_vector_map_path = (base_dir + "/FormattedDrugVector/FormattedAnchorHashDrugVector" +
                                                    str(anchor_hash_bit) + "_" + str(anchor_hash_layer) + ".csv");
                            target_vector_map_path = (
                            base_dir + "/FormattedTargetVector/FormattedAnchorHashTargetVector"
                            + str(anchor_hash_bit) + "_" + str(anchor_hash_layer) + ".csv");

                            true_labels = [];
                            predict_results = [];
                            predict_probabilities = [];
                            for foldIndex1 in range(0, fold_num):
                                # Initiate the test sample set
                                test_sample_set = [];
                                test_sample_set.extend(splited_folds_ps[foldIndex1]);
                                test_sample_set.extend(splited_folds_ns[foldIndex1]);
                                # Initiate the training sample set
                                train_sample_set = [];
                                for foldIndex2 in range(0, fold_num):
                                    if not foldIndex1 == foldIndex2:
                                        train_sample_set.extend(splited_folds_ps[foldIndex2]);
                                        train_sample_set.extend(splited_folds_ns[foldIndex2]);
                                fold_predict_probabilities, fold_true_labels = rf_xgb_ensemble_classifier(
                                    train_sample_set,
                                    test_sample_set, drug_vector_map_path, target_vector_map_path, classifiers, 10);
                                predict_probabilities.extend(fold_predict_probabilities);
                                predict_results.extend(
                                    ComparisonExp.merge_result(test_sample_set, fold_predict_probabilities));
                                true_labels.extend(fold_true_labels);
                            period = str(round((timeit.default_timer() - start), 2));
                            save_file_name = "AnchorHash(ns_ratio=" + str(ns_ratio) + ",anchor_hash_layer=" + str(
                                anchor_hash_layer) + ",anchor_hash_bit=" + str(
                                anchor_hash_bit) + ",classifier=EnsembleLearning," + ",ns_index=" + str(
                                ns_index) + ",cv_index=" + str(cv_index) + ",excute_time=" + period + ").csv";

                            save_path = CommonTool.base_dir + "/Result/python/" + save_file_name;
                            CommonTool.list_file_writer(predict_results, save_path);
                            auc_str = CommonTool.cal_auc(predict_probabilities, true_labels);
                            auc_str = save_file_name + "," + str(auc_str);
                            print auc_str;