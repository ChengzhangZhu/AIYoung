import timeit;
import MLHelper;
import CommonTool;
import EnsemblingLearning;
import NearestNeighbour;
import PairwiseKernelMethod;
import NegativeSampleSelection;
import SupportVectorMachine;
import BipartiteLocalModels;

# Merge the predict prefix and probability
def merge_result(test_sample_set, predict_probabilities):
    predict_results = [];
    test_size = len(test_sample_set);
    if len(test_sample_set)!=len(predict_probabilities):
        print 'len(test_sample_set)!=len(predict_probabilities)';
    else:
        for index in range(0, test_size):
            prefix_str = test_sample_set[index].replace(CommonTool.split_str, ",").replace("\n", "");
            predict_results.append(prefix_str + "," + str(predict_probabilities[index]));
    return predict_results;


# Main function
if __name__ == '__main__':
    # Common settings
    auc_list=[];
    ns_ratios = [1];
    fold_num = 10;
    ns_repeat_times = 5;
    cv_repeat_times = 5;
    anchor_hash_layers = [1];
    anchor_hash_bits = [48];
    PCA_bits = [48];
    classifiers = {
                   'RF': MLHelper.random_forest_classifier,
                   'XGB': MLHelper.xgboost
                  };
    positive_sample_list = CommonTool.list_file_reader(CommonTool.base_dir + "/Vector/FormattedPositiveSampleList.csv");
    drug_sim_map = NearestNeighbour.load_sim_map(CommonTool.base_dir + "/Similarity/DrugCSSim.csv");
    target_sim_map = NearestNeighbour.load_sim_map(CommonTool.base_dir + "/Similarity/TargetSeqSim.csv");
    for ns_index in range(1, (ns_repeat_times + 1)):
        for ns_ratio in ns_ratios:
            # Initiate negative samples
            negative_sample_size = (int)(ns_ratio*len(positive_sample_list));
            negative_sample_list = NegativeSampleSelection.random_negative_samples(positive_sample_list,negative_sample_size);
            for cv_index in range(1, (cv_repeat_times + 1)):
                # Split samples
                splited_folds_ps = CommonTool.split_sample_folds(positive_sample_list, fold_num);
                splited_folds_ns = CommonTool.split_sample_folds(negative_sample_list, fold_num);

                # # Classification for anchor hash compressed vectors using ensemble learning
                # base_dir = CommonTool.base_dir + "/Vector/CompressedVectors/AnchorHash";
                # for anchor_hash_layer in anchor_hash_layers:
                #     for anchor_hash_bit in anchor_hash_bits:
                #         if not (anchor_hash_layer == 1 and anchor_hash_bit == 64):
                #             start = timeit.default_timer();
                #             drug_vector_map_path = (base_dir + "/FormattedDrugVector/FormattedAnchorHashDrugVector" +
                #                                     str(anchor_hash_bit) + "_" + str(anchor_hash_layer) + ".csv");
                #             target_vector_map_path = (base_dir + "/FormattedTargetVector/FormattedAnchorHashTargetVector"
                #                                      + str(anchor_hash_bit) + "_" + str(anchor_hash_layer) + ".csv");
                #
                #             true_labels = [];
                #             predict_results = [];
                #             predict_probabilities = [];
                #             for foldIndex1 in range(0, fold_num):
                #                 # Initiate the test sample set
                #                 test_sample_set = [];
                #                 test_sample_set.extend(splited_folds_ps[foldIndex1]);
                #                 test_sample_set.extend(splited_folds_ns[foldIndex1]);
                #                 # Initiate the training sample set
                #                 train_sample_set = [];
                #                 for foldIndex2 in range(0, fold_num):
                #                     if not foldIndex1 == foldIndex2:
                #                         train_sample_set.extend(splited_folds_ps[foldIndex2]);
                #                         train_sample_set.extend(splited_folds_ns[foldIndex2]);
                #                 fold_predict_probabilities, fold_true_labels = EnsemblingLearning.rf_xgb_ensemble_classifier(train_sample_set,
                #                                             test_sample_set, drug_vector_map_path, target_vector_map_path,classifiers, 10);
                #                 predict_probabilities.extend(fold_predict_probabilities);
                #                 predict_results.extend(merge_result(test_sample_set, fold_predict_probabilities));
                #                 true_labels.extend(fold_true_labels);
                #             period = str(round((timeit.default_timer() - start),2));
                #             save_file_name = "AnchorHash(ns_ratio=" + str(ns_ratio) + ",anchor_hash_layer=" + str(anchor_hash_layer) + ",anchor_hash_bit=" + str(anchor_hash_bit) + ",classifier=EnsembleLearning," + ",ns_index=" + str(ns_index) + ",cv_index=" + str(cv_index) + ",excute_time="+ period + ").csv";
                #
                #             save_path = CommonTool.base_dir + "/Result/python/" + save_file_name;
                #             CommonTool.list_file_writer(predict_results, save_path);
                #             auc_str = CommonTool.cal_auc(predict_probabilities, true_labels);
                #             auc_str = save_file_name+ "," + str(auc_str);
                #             auc_list.append(auc_str);
                #             print auc_str;
                #
                # #Classification for PCA compressed vectors using ensemble learning
                # base_dir = CommonTool.base_dir + "/Vector/CompressedVectors/PCA";
                # for PCA_bit in PCA_bits:
                #     start = timeit.default_timer();
                #     drug_vector_map_path = base_dir + "/FormattedDrugVector/FormattedPCADrugVector" + str(PCA_bit) + ".csv";
                #     target_vector_map_path = base_dir + "/FormattedTargetVector/FormattedPCATargetVector" + str(PCA_bit) + ".csv";
                #
                #     true_labels = [];
                #     predict_results = [];
                #     predict_probabilities = [];
                #     for foldIndex1 in range(0, fold_num):
                #         # Initiate the test sample set
                #         test_sample_set = [];
                #         test_sample_set.extend(splited_folds_ps[foldIndex1]);
                #         test_sample_set.extend(splited_folds_ns[foldIndex1]);
                #         # Initiate the training sample set
                #         train_sample_set = [];
                #         for foldIndex2 in range(0, fold_num):
                #             if not foldIndex1 == foldIndex2:
                #                 train_sample_set.extend(splited_folds_ps[foldIndex2]);
                #                 train_sample_set.extend(splited_folds_ns[foldIndex2]);
                #         fold_predict_probabilities, fold_true_labels = EnsemblingLearning.rf_xgb_ensemble_classifier(train_sample_set, test_sample_set, drug_vector_map_path, target_vector_map_path,classifiers, 10);
                #         predict_probabilities.extend(fold_predict_probabilities);
                #         predict_results.extend(merge_result(test_sample_set, fold_predict_probabilities));
                #         true_labels.extend(fold_true_labels);
                #     period = str(round((timeit.default_timer() - start), 2));
                #     save_file_name = "PCA(ns_ratio=" + str(ns_ratio) + ",PCA_bit=" + str(PCA_bit) + ",classifier=EnsembleLearning," + ",ns_index=" + str(ns_index) + ",cv_index=" + str(cv_index) + ",excute_time="+ period + ").csv";
                #     save_path = CommonTool.base_dir + "/Result/python/" + save_file_name;
                #     CommonTool.list_file_writer(predict_results, save_path);
                #     auc_str = CommonTool.cal_auc(predict_probabilities, true_labels);
                #     auc_str = save_file_name + "," + str(auc_str);
                #     auc_list.append(auc_str);
                #     print auc_str;
                #
                # # Classification using NN
                # true_labels = [];
                # predict_results = [];
                # predict_probabilities = [];
                # start = timeit.default_timer();
                # for foldIndex1 in range(0, fold_num):
                #     # Initiate the test sample set
                #     test_sample_set = [];
                #     test_sample_set.extend(splited_folds_ps[foldIndex1]);
                #     test_sample_set.extend(splited_folds_ns[foldIndex1]);
                #     # Initiate the training sample set
                #     train_sample_set = [];
                #     for foldIndex2 in range(0, fold_num):
                #         if not foldIndex1 == foldIndex2:
                #             train_sample_set.extend(splited_folds_ps[foldIndex2]);
                #             train_sample_set.extend(splited_folds_ns[foldIndex2]);
                #     fold_predict_probabilities, fold_true_labels = NearestNeighbour.nearest_neighbour_classifier(positive_sample_list, train_sample_set, test_sample_set, drug_sim_map,target_sim_map);
                #     predict_probabilities.extend(fold_predict_probabilities);
                #     predict_results.extend(merge_result(test_sample_set, fold_predict_probabilities));
                #     true_labels.extend(fold_true_labels);
                # period = str(round((timeit.default_timer() - start), 2));
                # save_file_name = "NN(ns_ratio=" + str(ns_ratio) + ",classifier=NN" + ",ns_index=" + str(ns_index) + ",cv_index=" + str(cv_index) + ",excute_time="+ period + ").csv";
                # save_path = CommonTool.base_dir + "/Result/python/" + save_file_name;
                # CommonTool.list_file_writer(predict_results, save_path);
                # auc_str = CommonTool.cal_auc(predict_probabilities, true_labels);
                # auc_str = save_file_name + "," + str(auc_str);
                # auc_list.append(auc_str);
                # print auc_str;
                #
                # # Classification using Pairwise Kernel Method
                # true_labels = [];
                # predict_results = [];
                # predict_probabilities = [];
                # start = timeit.default_timer();
                # for foldIndex1 in range(0, fold_num):
                #     # Initiate the test sample set
                #     test_sample_set = [];
                #     test_sample_set.extend(splited_folds_ps[foldIndex1]);
                #     test_sample_set.extend(splited_folds_ns[foldIndex1]);
                #     # Initiate the training sample set
                #     train_sample_set = [];
                #     for foldIndex2 in range(0, fold_num):
                #         if not foldIndex1 == foldIndex2:
                #             train_sample_set.extend(splited_folds_ps[foldIndex2]);
                #             train_sample_set.extend(splited_folds_ns[foldIndex2]);
                #     fold_predict_probabilities, fold_true_labels = PairwiseKernelMethod.pair_wise_kernel_classifier(train_sample_set, test_sample_set, drug_sim_map, target_sim_map);
                #     predict_probabilities.extend(fold_predict_probabilities);
                #     predict_results.extend(merge_result(test_sample_set, fold_predict_probabilities));
                #     true_labels.extend(fold_true_labels);
                # period = str(round((timeit.default_timer() - start), 2));
                # save_file_name = "PKM(ns_ratio=" + str(ns_ratio) + ",classifier=PKM" + ",ns_index=" + str(
                #     ns_index) + ",cv_index=" + str(cv_index) + ",excute_time="+ period + ").csv";
                # save_path = CommonTool.base_dir + "/Result/python/" + save_file_name;
                # CommonTool.list_file_writer(predict_results, save_path);
                # auc_str = CommonTool.cal_auc(predict_probabilities, true_labels);
                # auc_str = save_file_name + "," + str(auc_str);
                # auc_list.append(auc_str);
                # print auc_str;

                # Classification using BLM
                true_labels = [];
                predict_results = [];
                predict_probabilities = [];
                start = timeit.default_timer();
                for foldIndex1 in range(0, fold_num):
                    # Initiate the test sample set
                    test_sample_set = [];
                    test_sample_set.extend(splited_folds_ps[foldIndex1]);
                    test_sample_set.extend(splited_folds_ns[foldIndex1]);
                    # Initiate the training sample set
                    train_sample_set = [];
                    for foldIndex2 in range(0, fold_num):
                        if not foldIndex1 == foldIndex2:
                            train_sample_set.extend(splited_folds_ps[foldIndex2]);
                            train_sample_set.extend(splited_folds_ns[foldIndex2]);
                    fold_predict_probabilities, fold_true_labels = BipartiteLocalModels.blm_classifier(train_sample_set, test_sample_set, drug_sim_map, target_sim_map);
                    predict_probabilities.extend(fold_predict_probabilities);
                    predict_results.extend(merge_result(test_sample_set, fold_predict_probabilities));
                    true_labels.extend(fold_true_labels);
                period = str(round((timeit.default_timer() - start), 2));
                save_file_name = "BLM(ns_ratio=" + str(ns_ratio) + ",classifier=BLM" + ",ns_index=" + str(
                    ns_index) + ",cv_index=" + str(cv_index) + ",excute_time="+ period + ").csv";
                save_path = CommonTool.base_dir + "/Result/python/" + save_file_name;
                CommonTool.list_file_writer(predict_results, save_path);
                auc_str = CommonTool.cal_auc(predict_probabilities, true_labels);
                auc_str = save_file_name + "," + str(auc_str);
                auc_list.append(auc_str);
                print auc_str;

                # Classification using raw vectors with ensemble learning
                true_labels = [];
                predict_results = [];
                predict_probabilities = [];
                drug_vector_map_path = (CommonTool.base_dir + "/Vector/RawVectors/DrugVector.csv");
                target_vector_map_path = (CommonTool.base_dir + "/Vector/RawVectors/TargetVectors.csv");
                start = timeit.default_timer();
                for foldIndex1 in range(0, fold_num):
                    # Initiate the test sample set
                    test_sample_set = [];
                    test_sample_set.extend(splited_folds_ps[foldIndex1]);
                    test_sample_set.extend(splited_folds_ns[foldIndex1]);
                    # Initiate the training sample set
                    train_sample_set = [];
                    for foldIndex2 in range(0, fold_num):
                        if not foldIndex1 == foldIndex2:
                            train_sample_set.extend(splited_folds_ps[foldIndex2]);
                            train_sample_set.extend(splited_folds_ns[foldIndex2]);
                    fold_predict_probabilities, fold_true_labels = EnsemblingLearning.rf_xgb_ensemble_classifier(train_sample_set,
                                                test_sample_set, drug_vector_map_path, target_vector_map_path,classifiers, 10);
                    predict_probabilities.extend(fold_predict_probabilities);
                    predict_results.extend(merge_result(test_sample_set, fold_predict_probabilities));
                    true_labels.extend(fold_true_labels);
                period = str(round((timeit.default_timer() - start),2));
                save_file_name = "RawVector(ns_ratio=" + str(ns_ratio) + ",classifier=EnsembleLearning," + ",ns_index=" + str(ns_index) + ",cv_index=" + str(cv_index) + ",excute_time="+ period + ").csv";

                save_path = CommonTool.base_dir + "/Result/python/" + save_file_name;
                CommonTool.list_file_writer(predict_results, save_path);
                auc_str = CommonTool.cal_auc(predict_probabilities, true_labels);
                auc_str = save_file_name+ "," + str(auc_str);
                auc_list.append(auc_str);
                print auc_str;

                # Classification for anchor hash compressed vectors using SVM
                base_dir = CommonTool.base_dir + "/Vector/CompressedVectors/AnchorHash";
                for anchor_hash_layer in anchor_hash_layers:
                    for anchor_hash_bit in anchor_hash_bits:
                        if not (anchor_hash_layer == 1 and anchor_hash_bit == 64):
                            start = timeit.default_timer();
                            drug_vector_map_path = (base_dir + "/FormattedDrugVector/FormattedAnchorHashDrugVector" +
                                                    str(anchor_hash_bit) + "_" + str(anchor_hash_layer) + ".csv");
                            target_vector_map_path = (base_dir + "/FormattedTargetVector/FormattedAnchorHashTargetVector"
                                                     + str(anchor_hash_bit) + "_" + str(anchor_hash_layer) + ".csv");

                            true_labels = [];
                            predict_results = [];
                            predict_probabilities = [];
                            for foldIndex1 in range(0, fold_num):
                                # Initiate the test sample set
                                test_sample_set = [];
                                test_sample_set.extend(splited_folds_ps[foldIndex1]);
                                test_sample_set.extend(splited_folds_ns[foldIndex1]);
                                # Initiate the training sample set
                                train_sample_set = [];
                                for foldIndex2 in range(0, fold_num):
                                    if not foldIndex1 == foldIndex2:
                                        train_sample_set.extend(splited_folds_ps[foldIndex2]);
                                        train_sample_set.extend(splited_folds_ns[foldIndex2]);
                                fold_predict_probabilities, fold_true_labels = SupportVectorMachine.svm_classifier(train_sample_set,
                                                            test_sample_set, drug_vector_map_path, target_vector_map_path);
                                predict_probabilities.extend(fold_predict_probabilities);
                                predict_results.extend(merge_result(test_sample_set, fold_predict_probabilities));
                                true_labels.extend(fold_true_labels);
                            period = str(round((timeit.default_timer() - start),2));
                            save_file_name = "AnchorHash(ns_ratio=" + str(ns_ratio) + ",anchor_hash_layer=" + str(anchor_hash_layer) + ",anchor_hash_bit=" + str(anchor_hash_bit) + ",classifier=SVM," + ",ns_index=" + str(ns_index) + ",cv_index=" + str(cv_index) + ",excute_time="+ period + ").csv";

                            save_path = CommonTool.base_dir + "/Result/python/" + save_file_name;
                            CommonTool.list_file_writer(predict_results, save_path);
                            auc_str = CommonTool.cal_auc(predict_probabilities, true_labels);
                            auc_str = save_file_name+ "," + str(auc_str);
                            auc_list.append(auc_str);
                            print auc_str;
    CommonTool.list_file_writer(auc_list, CommonTool.base_dir + "/Result/pythonComparison.csv");