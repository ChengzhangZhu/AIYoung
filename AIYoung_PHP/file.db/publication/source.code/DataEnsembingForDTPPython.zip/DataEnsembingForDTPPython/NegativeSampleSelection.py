import CommonTool;


# Randomly generate negative samples
def random_negative_samples(positive_sample_list,negative_sample_num):
    drug_list=[];
    target_list=[];
    # Initiate drug list and target list
    for ps in positive_sample_list:
        entities = ps.split(CommonTool.split_str);
        if len(entities) == 3:
            if not drug_list.__contains__(entities[0]):
                drug_list.append(entities[0]);
            if not target_list.__contains__(entities[1]):
                target_list.append(entities[1]);

    generated_num = 0;
    negative_sample_list=[];
    drug_list_size = len(drug_list);
    target_list_size = len(target_list);
    while generated_num < negative_sample_num:
        drug_index = CommonTool.get_random_num(drug_list_size);
        target_index = CommonTool.get_random_num(target_list_size);
        negative_interaction = drug_list[drug_index]+CommonTool.split_str+target_list[target_index]+CommonTool.split_str;
        if (not positive_sample_list.__contains__(negative_interaction+"1"))&(not negative_sample_list.__contains__(negative_interaction+"0")):
            negative_sample_list.append(negative_interaction+"0");
            generated_num += 1;
    return negative_sample_list;


# Main function
if __name__ == '__main__':
    positive_sample_list = CommonTool.list_file_reader(CommonTool.base_dir + "\Vector\FormattedPositiveSampleList.csv");
    random_negative_samples(positive_sample_list,len(positive_sample_list));